const app = require("./app")

app.listen(3100, () => {
    console.log("server rodando na porta 3100");
});